import logging
import time

import httpx


class SFSClient:
    def __init__(self, sfs_url: str, sfs_api_key: str) -> None:
        self._client = httpx.Client()
        self.SFS_URL = sfs_url
        self._sfs_api_key = sfs_api_key
        self.log = logging.getLogger("SFSClient")

    def index(self, tenant: str = 'default') -> str:
        r = httpx.post(self.SFS_URL + f'/admin/dataflows?api-key={self._sfs_api_key}&tenant={tenant}')
        if r.status_code == 200:
            return r.json().get('loadingId')

    def wait_for_reindex(self, dataspace_id: str, loading_id: str, tenant: str = 'default', startup_sleep: int = 0,
                         timeout: int = 600,
                         backoff: int = 30) -> bool:
        start = time.time()
        time.sleep(startup_sleep)
        while True:
            r = httpx.get(self.SFS_URL + f'/admin/report?api-key={self._sfs_api_key}&tenant={tenant}')
            if r.status_code != 200:
                self.log.error(f"Failed to get status of SFS loading {loading_id}")

            loading = r.json().get('loadings').get(loading_id) or self.log.error(
                f"Loading {loading_id} not found in SFS")
            dataspace = loading.get(dataspace_id) or self.log.error(f"Dataspace {dataspace_id} not found in SFS")

            dataflows = dataspace.get('dataflows')
            if dataflows:
                if dataflows.get('indexed'):
                    self.log.info("Dataflows indexed")
                    return True
            if time.time() - start > timeout:
                self.log.error(f'Timeout waiting for dataflows to be indexed {timeout} seconds passed')
                return False
            self.log.info("Still not information retrieved about the loading, waiting...")
            time.sleep(backoff)
