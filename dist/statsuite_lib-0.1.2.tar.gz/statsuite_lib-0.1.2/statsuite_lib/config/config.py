import logging

import httpx


class ConfigClient:
    """Client for the SDMX Faceted search service"""

    def __init__(self, config_url: str) -> None:
        """Inits the client

        Args:
            config_url: Endpoint url for Config service.
        """

        self._client = httpx.Client()
        self.CONFIG_URL = config_url
        self.log = logging.getLogger("ConfigClient")
        self.log.level = logging.INFO

    def get_tenants(self, tenant: str = "default") -> str:
        """Gets tenants config

        Returns:
            loadingId(str)
        """
        resp = httpx.get(
            f"{self.CONFIG_URL}/configs/tenants.json"
        )
        if resp.status_code == 200:
            from .models import Tenants

            loading = Tenants.model_validate(resp.json())
            return loading
